
export * from './tabs/ManagementCustomersTab';
export * from './tabs/ManagementVehiclesTab';
export * from './tabs/ManagementDiagramsTab';
export * from './tabs/ManagementStaffTab';
export * from './tabs/ManagementRolesTab';
export * from './tabs/ManagementEntitiesTab';
export * from './tabs/ManagementSuppliersTab';
export * from './tabs/ManagementPartsTab';
export * from './tabs/ManagementPackagesTab';
export * from './tabs/ManagementNominalCodesTab';
